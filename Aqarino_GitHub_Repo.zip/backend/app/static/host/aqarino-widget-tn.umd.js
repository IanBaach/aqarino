
(function(){
  // Simple Aqarino UMD widget (minimal)
  function createWidget(){
    const root = document.createElement('div'); root.className = 'aq-widget';
    const btn = document.createElement('button'); btn.className='aq-button'; btn.innerHTML = '<svg width="24" height="24" viewBox="0 0 24 24"><rect width="100%" height="100%" rx="4" fill="white" opacity="0.06"/></svg>';
    root.appendChild(btn);
    const win = document.createElement('div'); win.className='aq-window'; win.style.display='none';
    win.innerHTML = '<div class="aq-header"><img class="logo" src="/static/host/door_photo.png" onerror="this.src=\'/frontend/assets/door_logo.svg\'"><div><strong>Aqarino</strong><div style="font-size:12px;opacity:0.9">Your real estate assistant</div></div></div><div class="aq-messages" id="aq-msgs"></div><div class="aq-footer"><input class="aq-input" id="aq-inp" placeholder="Ask about this listing..."><button class="aq-send" id="aq-send">Send</button></div>';
    root.appendChild(win);
    document.body.appendChild(root);

    btn.addEventListener('click', ()=>{ win.style.display = win.style.display==='none' ? 'block' : 'none'; });

    document.addEventListener('click', function(e){
      if(!root.contains(e.target) && win.style.display==='block'){ /* keep open */ }
    });

    document.getElementById('aq-send').addEventListener('click', async ()=>{
      const inp = document.getElementById('aq-inp');
      const text = inp.value.trim(); if(!text) return;
      const msgs = document.getElementById('aq-msgs');
      const bubble = document.createElement('div'); bubble.className='aq-msg user'; bubble.innerText = text; msgs.appendChild(bubble);
      inp.value='';
      // post lead to backend
      try{
        const payload = { visitor: { name: 'Web Visitor' }, listing: { external_id: (window.AQ_INIT && window.AQ_INIT[0] && window.AQ_INIT[0].listing && window.AQ_INIT[0].listing.external_id) || 'demo' }, message: text };
        await fetch((window.AQ_BACKEND || '/api') + '/leads', { method:'POST', headers:{'Content-Type':'application/json'}, body: JSON.stringify(payload) });
        const agent = document.createElement('div'); agent.className='aq-msg agent'; agent.innerText = 'Thanks — your message has been sent to the agency. An agent will contact you soon.'; msgs.appendChild(agent);
      }catch(err){
        const agent = document.createElement('div'); agent.className='aq-msg agent'; agent.innerText = 'Network error — please try again later.'; msgs.appendChild(agent);
      }
      msgs.scrollTop = msgs.scrollHeight;
    });
  }

  if(document.readyState==='loading') document.addEventListener('DOMContentLoaded', createWidget); else createWidget();
})();
