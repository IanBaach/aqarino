export function initAqarino(){console.log("Aqarino ESM init");}
