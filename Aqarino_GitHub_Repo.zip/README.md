Aqarino v2 - Simple Modular Edition (FastAPI + Jinja dashboard)

Quick start:
  unzip Aqarino_v2_simple.zip
  cd Aqarino_v2_simple
  ./start-demo.sh
Then open http://localhost:8081 (demo) and http://localhost:8000 (dashboard)


## Extras added in full package
- Unit tests (pytest) in /tests
- CURL examples in CURL_EXAMPLES.md
- send_pending_export.py script to email CSV export (tools/)
- Render deploy file (render.yaml)
- GitHub Actions workflow for Pages (.github/workflows)

Usage:
- To run tests: ./run_tests.sh (ensure backend running)
- To send export manually: python3 tools/send_pending_export.py (set LEAD_EMAIL_TO and SMTP envs)

UMD widget not found in /mnt/data — placeholder remains. To enable chat, add your widget file at backend/app/static/host/aqarino-widget-tn.umd.js


## GitHub Ready Package
This repo is prepared for upload to GitHub under owner `IanBaach` with name `aqarino`.

### Brand theme (from door image)
Primary: #0077B6
Accent: #EAD7B7
Background: #F9F9F9

### How to push to GitHub
```bash
# from this folder
git init
git add .
git commit -m "Aqarino initial commit - Tunisian door theme"
# create repo on GitHub named 'aqarino' then:
git remote add origin https://github.com/IanBaach/aqarino.git
git branch -M main
git push -u origin main
```

If you have `gh` CLI, you can create the repo automatically:
```bash
gh repo create IanBaach/aqarino --public --source=. --remote=origin --push
```
